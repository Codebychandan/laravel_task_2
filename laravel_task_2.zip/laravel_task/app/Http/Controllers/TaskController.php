<?php

namespace App\Http\Controllers;

use App\Http\Middleware\ApiKeyAuthenticationMiddleware;
use Illuminate\Http\Request;
use App\Models\Task;
use Illuminate\Support\Facades\Auth;

class TaskController extends Controller
{

    public function __construct(){
        $this->middleware(ApiKeyAuthenticationMiddleware::class);
    }
    public function addTask(Request $req){

        if(!$this->authenticate($req)){
            return response()->json(['status' => 0, 'message' => 'Invalid API Key']);
        }

        $req->validate([
            'task' => 'required|string',
            'user_id'=> 'required|exists:users,id'
        ]);

        $task = Task::create([
            'user_id'=>$req->user_id,
            'task'=> $req->task
        ]);

        return response()->json(['status'=>1, 'message'=> 'Successfully created a task', 'task'=>$task]);
    }

    public function updateTaskStatus(Request $req){

        if(!$this->authenticate($req)){
            return response()->json(['status'=> 0, 'message'=>'Invalid API Key' ]);
        }

        $req->validate([
            'task_id' => 'required|exists:tasks,id',
            'status'=> 'required|in:pending,done',
        ]);
        
        // update record
        $task = Task::findOrFail($req->task_id);
        $task->status = $req->status;
        $task->save();

        $message = ($req->status === 'done') ? 'Marked task as done' : 'Marked task as pending';

        return response()->json(['status' => 1, 'message' => $message, 'task' => $task]);

    }

    private function authenticate(Request $req){
        return $req->header('API_KEY') === 'helloatg';
    }
}
